﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using Communication;

namespace Client
{
    class SocketClient
    {
       //private int port;
        private static Socket senderclient;
        public void SendMsg(byte[] msg)
        {
            SendMessageFromSocket(11000, msg);
        }
        public byte[] GetMsg()
        {
            // Буфер для входящих данных
            byte[] bytes = new byte[1024];
            // Получаем ответ от сервера
            int bytesRec = senderclient.Receive(bytes);
            return bytes;
        }
        public static void ConnectToServer(int port, string IPServer)
        {
            // Соединяемся с удаленным устройством

            // Устанавливаем удаленную точку для сокета
            IPHostEntry ipHost = Dns.GetHostEntry(IPServer);//IPAddress.Parse(IPServer));//IPAddress.Parse("localhost"));//"172.18.30.55"));//DEKSTOP-G2J1541");
            IPAddress ipAddr = ipHost.AddressList[0];
            IPEndPoint ipEndPoint = new IPEndPoint(ipAddr, port);

            Socket sender = new Socket(ipAddr.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            senderclient = sender;
            sender.Connect(ipEndPoint);
           /* try
            {
                // Соединяем сокет с удаленной точкой
                sender.Connect(ipEndPoint);
                return 0;
            }
            catch (SocketException e)
            {
                if (e.ErrorCode == -2)
                    return -1;
            }*/
        }
        static void SendMessageFromSocket(int port, byte[] msg)
        {

            // Отправляем данные через сокет
            int bytesSent = senderclient.Send(msg);

            // Используем рекурсию для неоднократного вызова SendMessageFromSocket()
            /*if (message.IndexOf("<TheEnd>") == -1)
                SendMessageFromSocket(port, message);*/

            
        }
        public void SocketClose() //закрываем соединение
        {
            // Освобождаем сокет
            senderclient.Shutdown(SocketShutdown.Both);
            senderclient.Close();
        }

        public bool ProcessingMsg(Message msg)
        {
            if (msg.getCodeStatus() == 200)
                return true;
            else return false;
        }
        public string ProcessingErorr(Message msg)
        {
            if (msg.getCodeStatus() == 404)
            { return "Запись не сущуствует"; }
            else if (msg.getCodeStatus() == 405)
            {
                return "Запись уже существует";
            }
            else if (msg.getCodeStatus() == 406)
            { return "В настоящий момент запись нельзя редактировать, попробуйте позднее"; }
            else return "Неизвестная ошибка";
        }

        
    }
}
